This is my entry for the [Ludum Dare](http://ludumdare.com/compo) #23 compo. Play it [here](http://nornagon.net/games/polarity)!

You're an atom. Change your polarity to navigate your way to the exit!

![Title screen](http://nornagon.net/games/polarity/title.png)
